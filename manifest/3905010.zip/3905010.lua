-- Generated with Luie @ https://lua.tools/
-- 3905010 - ONE PIECE: Grand Gourmet
-- Generated 2026-10-26 09:20:14 UTC
-- # Depots (Total/DLC/Shared): 4/0/2

-- Main AppID
addappid(3905010)

-- Main Depots
addappid(3905011, 1, "722f0921e6719afc1fbb86c4225eee5df9ec793ab4fbe3090d13efa9e6aeda6e")
setManifestid(3905011, "4770056494676873762", 217389165)

-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- Missing Depots (We don't have the keys yet lol): 3905012
