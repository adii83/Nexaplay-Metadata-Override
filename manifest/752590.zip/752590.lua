addappid(752590) -- A Plague Tale: Innocence
-- MAIN APP DEPOTS
addappid(752591, 1, "31c0eb1a38b3926e0e589c25300225886ac653a8415d3612864cd26664681460") -- A Plague Tale: Innocence Content
-- SHARED DEPOTS (from other apps)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- VC 2017 Redist (Shared from App 228980)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(967380) -- A Plague Tale Innocence - Coats of Arms DLC

-- Made with love by LightningFast⚡💜