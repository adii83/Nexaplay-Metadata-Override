-- Generated with Luie @ https://lua.tools/
-- 992490 - iVRy Driver for SteamVR
-- Generated 2026-10-26 07:02:09 UTC
-- # Depots (Total/DLC/Shared): 16/13/2

-- Main AppID
addappid(992490, 1, "658e5685eabc8ace17f7629a3de04f8ee6c154bd775e687902389794d05ba47d")

-- Main Depots
addappid(992491, 1, "1a9d7637e8c9d0e2be9e5c3e66639ca1838a7bff8edcabb3c3208ecabd227a33") -- (windows)
setManifestid(992491, "1076313503647708676", 125989920)

-- DLC's (no depot keys required)
addappid(1005972) -- iVRy Driver for SteamVR (Mobile Device Premium Edition)
addappid(2261231) -- iVRy Driver for SteamVR (Pico Premium Edition)
addappid(2829580) -- iVRy Driver for SteamVR (Apple Vision Pro Premium Edition)
addappid(3458770) -- DLC 3458770

-- DLC's (with depot keys)
-- iVRy Driver for SteamVR (PSVR Lite Edition) (AppID: 1005970)
addappid(1005970)
addappid(1005973, 1, "d31395a182361bf1c83d2df7f61661f967c0e0f8bbbd1a40281919f8d32ddd26") -- (windows)
setManifestid(1005973, "5576791049597500237", 24777055)
-- iVRy Driver for SteamVR (PSVR Premium Edition) (AppID: 1005971)
addappid(1005971)
addappid(1005971, 1, "94ccf3272b8560103307bbe340d12d31304f39b2e1562a74fb837bd466398db3") -- (windows)
setManifestid(1005971, "4689126566800086861", 24777055)
-- BETA: iVRy Driver for SteamVR (PSVR2 Premium Edition) (AppID: 1021000)
addappid(1021000)
addappid(1021001, 1, "7a0b82be234693044e6c268d9bae8c149420b9d61a389bfc67aef13f70e3efdf") -- (windows)
setManifestid(1021001, "2208131508724712351", 22523916)
-- iVRy PSMoveService Driver for SteamVR (AppID: 1257790)
addappid(1257790)
addappid(1257791, 1, "a45c3b37021d94dc31ff54e0988ba30c708406da0d72efe65174a469596a07c9") -- (windows)
setManifestid(1257791, "3289814755905279604", 48586014)
-- iVRy for SteamVR (GearVR/Oculus App Installer) (AppID: 1487090)
addappid(1487090)
addappid(1487094, 1, "c26e07e3c44c60bd0358033d1fe3c4ceea9a118b0d494c04932c1cbcd75c42d5")
setManifestid(1487094, "1141916683664621979", 7090979)
-- iVRy for SteamVR (Android/Daydream App Installer) (AppID: 1487091)
addappid(1487091)
addappid(1487091, 1, "9a0d02c15d614e076b94c212ba487834aeaee38533c7c21cf250ef7c57fb2ca4") -- (windows, 64-bit)
setManifestid(1487091, "22964565055215754", 7139413)
-- IVRy Monado Tracker for SteamVR (AppID: 1591080)
addappid(1591080)
addappid(1591081, 1, "0aca959d4c7877c0993c400d48c585da1017a10db653e7bf4d31525de80e2a51") -- (windows, 64-bit)
setManifestid(1591081, "4971718085248293330", 71197934)
-- iVRy for SteamVR (Pico App Installer) (AppID: 2261230)
addappid(2261230)
addappid(2261232, 1, "09f502c6060ead92b12dd00d48233919dc5688b0f05b702531ea40e1ba478ca2")
setManifestid(2261232, "6763483241696906003", 9759443)
-- BETA: iVRy Driver for SteamVR (PSVR2 Lite Edition) (AppID: 2772740)
addappid(2772740)
addappid(2772741, 1, "d87c8bb05aa5c73b6457e6a72310995906ba75f98f21fdc692ecfe4f82f159d9") -- (windows)
setManifestid(2772741, "5289065185926244738", 22523916)
-- iVRy GearVR System Files Installer (AppID: 3260890)
addappid(3260890)
addappid(3260891, 1, "037629a2f44a4420d209aa927eea9b9108f40afc02190b31e062beb2961a53fd")
setManifestid(3260891, "5549041756764497517", 378325418)
-- BETA: iVRy for SteamVR (Vive Wave Installer) (AppID: 3458760)
addappid(3458760)
addappid(3458761, 1, "d5a2a43f82e5c41d82aa3e8cca911bb9df61f3b735c88335dce7ce1489a5c0ea") -- (windows, 64-bit)
setManifestid(3458761, "2500340301218782479", 26266306)

-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- (windows)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- (windows)

-- Missing Depots (We don't have the keys yet lol): 1487095, 1501871
